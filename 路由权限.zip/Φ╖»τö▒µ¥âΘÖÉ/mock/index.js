const Mock = require('mockjs')

// 房源列表
const houseData = Mock.mock({
    "list|100-200": [
        {
            id: "@id",
            name: "@ctitle(3,6)",
            area: "@city(true)",
            "price|400-1000": 1,
            "status|1": [true, false],
            img: "@image(100x100, @color)"
        }
    ]
})

//用户角色列表
const userList = [
    {
        username: 'admin',
        id: "zhangsan_01",
        password: '123',
        name: '张三',
        authcodes: ['10001', "10002", "10003", "10004", "10005", "10006"]
    },
    {
        username: 'zty',
        id: "zhangsan_01",
        password: '123',
        name: '张三',
        authcodes: ['10001', "10002", "10003", "10004", "10005", "10006"]
    },
    {
        username: 'user',
        id: "lisi_01",
        password: '123',
        name: '李四',
        authcodes: ["10002", '10001', "10003", "10004"]
    }
]

const carData = Mock.mock({
    detailData: {
        title: "@ctitle(3,7)",
        banner: {
            facade: {
                id: "@id",
                "img|10-30": ["@image(100x100,@color)"],
                title: "外观"
            },
            trim: {
                id: "@id",
                "img|10-30": ["@image(100x100,@color)"],
                title: '内饰'
            },
            interspace: {
                id: "@id",
                "img|10-30": ["@image(100x100,@color)"],
                title: "空间"
            }
        }
    }
})

module.exports = {
    userList,
    houseData: houseData.list,
    carData: carData.detailData
}


