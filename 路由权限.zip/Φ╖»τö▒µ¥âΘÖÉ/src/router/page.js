import Address from '@/views/Address.vue'
import House from '@/views/House.vue'
import Subway from '@/views/Subway.vue'
import Advertising from '@/views/Advertising.vue'
import Personnel from '@/views/Personnel.vue'
import Role from '@/views/Role.vue'


const tabRouter = [
    {
        path: '/address',
        name: "Address",
        component: Address,
        // 路由自定义属性
        mate: {
            title: '地区管理',
            authcode: '10001'
        }
    },
    {
        path: '/house',
        name: 'House',
        component: House,
        mate: {
            title: '房源管理',
            authcode: '10002'

        }
    },
    {
        path: '/subway',
        name: 'Subway',
        component: Subway,
        mate: {
            title: '地铁管理',
            authcode: '10003'

        }
    },
    {
        path: '/advertising',
        name: 'Advertising',
        component: Advertising,
        mate: {
            title: '广告位管理',
            authcode: '10004'

        }
    },
    {
        path: '/personnel',
        name: 'Personnel',
        component: Personnel,
        mate: {
            title: '人员权限',
            authcode: '10005'

        }
    },
    {
        path: '/role',
        name: 'Role',
        component: Role,
        mate: {
            title: '角色权限',
            authcode: '10006'
        }
    }
]

export default tabRouter
