import { getUserInfo } from "@/api";
import tabRouter from '@/router/page'
import Store from '@/store'


// 获取用户信息
async function userInfo() {

    // 获取用户信息
    //res.data ==> 返回值 ==> 返回值中包含当前登录用户的数据:id,name,authcodes
    const res = await getUserInfo()
    // 将用户信息保存到vuex

    // 过滤路由表  
    const newtabRouter = tabRouter.filter(item => {
        return res.data.authcodes.some(val => val === item.mate.authcode)
    })

    // 将路由表保存到vuex中
    Store.commit('CHANGE_ROUTER_LIST', newtabRouter)

    // 将用户信息保存到vuex
    Store.commit('CHANGE_USER_INFO', res.data)
}

export {
    userInfo
}


// 用户表

// user  pas  id  auth  authid
// 小王   123  1   学生    1
// 小李   123  2   学生    1
// 小孙   123  3   学生    1
// 小宋   123  4   老师    2
// 小陈   123  5   老师    2