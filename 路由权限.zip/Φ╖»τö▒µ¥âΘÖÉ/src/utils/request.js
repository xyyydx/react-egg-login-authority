import axios from 'axios'
import { Message } from 'element-ui'

// 拦截请求  在发送请求之前
axios.interceptors.request.use(config => {
    // 携带请求头
    const token = localStorage.getItem('token')
    
    if (token) {
        config.headers = {
            ...config.headers,
            Authorization: token
        }
    }
    return config
})

// 拦截响应（返回值）  在获取数据之后 未到页面之前
axios.interceptors.response.use(config => {

    if (config.data.code !== 0) {
        // 请求错误
        Message(config.data.msg)
    } else {
        // 请求成功
        return config.data
    }

}, err => {
    // 请求失败 拦截异常  网络响应码不为200
    return new Promise.reject(err)
})


export default axios

