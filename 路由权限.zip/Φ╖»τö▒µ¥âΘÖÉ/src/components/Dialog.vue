<template>
  <div class="dialog-box" v-if="visible">
    <div class="dialog">
      <!-- 具名插槽 -->
      <h3>
        <slot name="subTitle"></slot>
      </h3>

      <div class="dialog-body">
        <slot name="body"></slot>
      </div>
      <slot name="footerslot"></slot>
      <div class="footer">
        <el-button @click="closeDialog">取消</el-button>
        <el-button @click="editOk">确认</el-button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {},
  props: {
    visible: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {};
  },
  computed: {},
  methods: {
    closeDialog() {
      // // $emit  创建一个自定义事件
      this.$emit('close')

      // 发布者
      this.$bus.$emit("showTost", "弹框以关闭");
    },
    editOk() {
      this.$emit('editOk')
    }
  },
};
</script>

<style lang="scss" scoped>
.dialog-box {
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0;
  left: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
}

.dialog {
  width: 500px;
  min-height: 200px;
  background: #fff;
  display: flex;
  flex-direction: column;
  padding: 20px;
}

.dialog-body {
  flex: 1;
}

.footer {
  flex-shrink: 0;
  height: 50px;
  display: flex;
  justify-content: flex-end;
}
</style>

