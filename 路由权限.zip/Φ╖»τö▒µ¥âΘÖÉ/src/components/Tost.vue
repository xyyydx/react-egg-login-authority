<template>
  <div v-if="isShow" class="tost-box">
    {{ content }}
    <h1>
      <slot></slot>
    </h1>
  </div>
</template>

<script>
export default {
  data() {
    return {
      content: "",
      isShow: false,
    };
  },
  mounted() {
    // 订阅者
    this.$bus.$on("showTost", (content) => {
      this.content = content;

      // 将轻提示显示出来
      this.isShow = !this.isShow;

      // 3秒后 关闭轻提示
      setTimeout(() => {
        this.isShow = !this.isShow;
      }, 3000);
    });
  },
};
</script>

<style lang="scss" scoped>
.tost-box {
  min-width: 300px;
  min-height: 70px;
  border: 1px solid #ccc;
  position: fixed;
  top: 200px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  align-items: center;
  justify-content: center;
  background: skyblue;
  border-radius: 20px;
  color: #fff;
}
</style>