<template>
  <div class="header-box">
    <h3>宏业找房后台管理系统</h3>
    <div>
      {{ userInfo.name }}管理员 |
      <el-button @click="outLogin">退出</el-button>
    </div>
  </div>
</template>

<script>

import { mapState } from "vuex";

export default {
  data() {
    return {};
  },
  computed: {
    ...mapState(["userInfo"]),
  },
  created() {

  },
  methods: {
    outLogin() {
      // 退出登录
      // 删除 token
      localStorage.removeItem("token");

      // 返回到登录页
      this.$router.push("/login");
    },
  },
};
</script>

<style lang="scss" scoped>
.header-box {
  width: 100%;
  height: 79px;
  background: rgb(51, 51, 51);
  display: flex;
  align-items: center;
  color: #fff;
  justify-content: space-between;
  padding: 0 23px;
  flex-shrink: 0;
}
</style>