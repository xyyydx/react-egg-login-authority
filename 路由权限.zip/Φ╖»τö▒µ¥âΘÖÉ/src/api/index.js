import request from '@/utils/request'

// 获取验证码
function getAuthCode() {
    return request({
        url: '/api/getAuthCode',
        method: 'post'
    })
}

// 登录  data:参数
function Login(data) {
    return request({
        url: '/api/login',
        method: "post",
        data
    })
}

// 获取用户信息
function getUserInfo(data) {
    return request({
        url: '/api/getUserInfo',
        method: 'post',
        data
    })
}

// 获取角色列表
function getRoleList(data) {
    return request({
        url: '/api/getRoleList',
        method: 'post',
        data
    })
}

function getHouseList(data) {
    return request({
        url: '/api/getHouseList',
        method: 'post',
        data
    })
}

// 删除
function deleteItem(data) {
    return request({
        url: '/api/delete',
        method: 'post',
        data
    })
}

function editItem(data) {
    return request({
        url: '/api/editItem',
        method: 'post',
        data
    })
}

function addItem(data) {
    return request({
        url: '/api/addItem',
        method: 'post',
        data
    })
}

function carDetail(data) {
    return request({
        url: '/api/carDetail',
        method: 'post',
        data
    })
}

export {
    getAuthCode,
    Login,
    getUserInfo,
    getRoleList,
    getHouseList,
    deleteItem,
    editItem,
    addItem,
    carDetail
}