<template>
    <div class="address-box">
    <h1>This is an Subway page</h1>
  </div>
</template>