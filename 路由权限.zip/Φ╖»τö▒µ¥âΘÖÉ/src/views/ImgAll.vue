<template>
    <div>
        <img v-for="(item, idx) in imgs"  :src="item" :key="idx" alt="">
    </div>
</template>
<script>
export default {
    data() {
        return {
            imgs: []
        }
    },
    created() {
        this.imgs = this.$route.params.imgs
    }
}
</script>