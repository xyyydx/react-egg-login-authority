<template>
  <div class="address-box">
    <Title title="地区管理"> </Title>
    <el-button @click="changeDialog">添加</el-button>
    <Dialog>
      <!-- 具名插槽 -->
      <template slot="subTitle">
        <div>我是父组件传来的副标题</div>
      </template>
      <template slot="footerslot">
        <div>
          底部插槽
        </div>
      </template>
    </Dialog>
    <Tost> dahdwa </Tost>

    <el-button @click="back">返回</el-button>
  </div>
</template>


<script>
import Title from "@/components/Title.vue";
import Dialog from "@/components/Dialog.vue";
import Tost from "@/components/Tost.vue";
import { mapMutations } from "vuex";
export default {
  components: {
    Title,
    Dialog,
    Tost,
  },
  data() {
    return {};
  },
  methods: {
    ...mapMutations(["CHANGE_VISIBLE"]),
    changeDialog() {
      this.CHANGE_VISIBLE();
      // this.visible = !this.visible
    },
    back() {
      console.log(this.$router);
      this.$router.back();
    },
  },
};
</script>
