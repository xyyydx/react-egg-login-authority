<template>
  <div class="public">
  </div>
</template>

<script>

export default {
  name: 'Home',
  components: {
  }
}
</script>
