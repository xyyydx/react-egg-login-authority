<template>
  <div>
    <div class="banner">
      <el-carousel>
        <el-carousel-item v-for="item in 4" :key="item">
          <img :src="banner[item]" alt="" />
        </el-carousel-item>
      </el-carousel>
      <span class="num" @click="toImgDetail">{{ imgNum }}张照片</span>
    </div>
  </div>
</template>

<script>
import { carDetail } from "@/api";

export default {
  created() {
    this.getDetail();
  },
  data() {
    return {
      banner: [],
      imgNum: 0,
      bannerImg: {}
    };
  },
  methods: {
    getDetail() {
      carDetail().then((res) => {
        this.bannerImg = res.data.banner;

        // 遍历对象 获取图片的总数
        for (let item in this.bannerImg) {
          this.banner = this.banner.concat(this.bannerImg[item].img);
        }
        this.imgNum = this.banner.length;
      });
    },
    toImgDetail() {
      this.$router.push({path: "/imgDetail" });
    },
  },
};
</script> 
<style lang="scss" scoped>
.banner {
  position: relative;
  img {
    width: 100%;
    height: 100%;
  }
  .num {
    position: absolute;
    right: 20px;
    bottom: 20px;
    z-index: 999;
    display: flex;
    padding: 10px;
    background: rgba(0, 0, 0, 0.5);
    border-radius: 20px;
    color: #fff;
  }
}
</style>