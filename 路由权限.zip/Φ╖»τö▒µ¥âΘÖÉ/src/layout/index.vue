<template>
  <div class="layout public">
    <Header />
    <div class="layout-body">
      <MenuTab />
      <div class="layout-content">
        <router-view />
      </div>
    </div>
  </div>
</template>

<script>
import Header from "@/components/Header.vue";
import MenuTab from "@/components/MenuTab.vue";


export default {
  components: {
    Header,
    MenuTab,
  },
  data() {
    return {};
  },


};
</script>

<style lang="scss" scoped>
.layout {
  display: flex;
  flex-direction: column;
}

.layout-body {
  display: flex;
  flex: 1;
}

.layout-content {
  padding: 20px;
  width: 100%;
}
</style>