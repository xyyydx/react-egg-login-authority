<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
import { userInfo } from "@/utils";
export default {
  created() {
    // 获取用户信息
    userInfo();
  },
};
</script>

<style lang="scss">
html,
body,
#app,
.public {
  width: 100%;
  height: 100%;
}

* {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
  list-style: none;
  text-decoration: none;
}
</style>
